#include <stdio.h>
#include <unistd.h>
#include <string.h>
//#include "spi_slave.h"
//#include "sysct1.h"
#include "fpioa.h"
#include "gpiohs.h"
#include "gpio.h"
#include "dw_spi.h"
#include "spi.h"
#include "bsp.h"
#include "sysctl.h"
#include "plic.h"
#include "uarths.h"
#include <lcd.h>
#include "ov5640.h"
#include "ov2640.h"
#include "nt35310.h"
#include "utils.h"
#include "cnn.h"
#include "region_layer.h"
#include "board_config.h"
#include "uart.h"
#include "sysctl.h"
#include "bsp.h"
#include "sleep.h"
#include "lcd.h"
#include "nt35310.h"
#include "picojpeg.h"
#include "picojpeg_util.h"
#include "kpu.h"
#include <platform.h>
#include <printf.h>
#include <stdlib.h>
#include <float.h>
#define INCBIN_STYLE INCBIN_STYLE_SNAKE
#define INCBIN_PREFIX
#include "incbin.h"

#define CLASS10 1

#define PLL0_OUTPUT_FREQ 1000000000UL
#define PLL1_OUTPUT_FREQ 400000000UL
#define PLL2_OUTPUT_FREQ 45158400UL

/* 双核变量定义区 */
//该结构体为两个核之间的共享的内存信息(MI)
//核0把spi传入的jpeg数据转化为rgb888,核1把  转化后的数据传入kpu,计算,输出到uart
#define  N 	5					//定义缓存区为5个
#define  BUFF_WIDE  (3 * 320 * 240)
typedef struct 
{
	semaphore_t semaphore_lock; //核1与核2之间的信号量
	uint8_t produce_count;  	//生产产品的数量
	uint8_t empty_count;    	//空的数量，即未生产的数量
	uint8_t in;   				//生产者的指针
	uint8_t out;  				//消费者的指针
	uint8_t rgb888_buff[N][BUFF_WIDE]; //核0与核1共享的内存
}Core_Share_MI;
static Core_Share_MI core_share_mi;

volatile uint32_t g_ai_done_flag;

const float features[] = {5.1,3.8,1.9,0.4};
const char *labels[] = { "setosa", "versicolor", "virginica" };

extern const unsigned char gImage_image[] __attribute__((aligned(128)));
static uint16_t lcd_gram[320 * 240] __attribute__((aligned(32)));

kpu_model_context_t task1;

INCBIN(model, "iris.kmodel");

static void ai_done(void* userdata)
{
    g_ai_done_flag = 1;
    
    float *features;
    size_t count;
    kpu_get_output(&task1, 0, (uint8_t **)&features, &count);
    count /= sizeof(float);

    size_t i;
    for (i = 0; i < count; i++)
    {
        if (i % 64 == 0);
            //printf("\n");
        //printf("%f, ", features[i]);
    }

    //printf("\n");
}

size_t argmax(const float *src, size_t count)
{
    float max = FLT_MIN;
    size_t max_id = 0, i;
    for (i = 0; i < count; i++)
    {
        if (src[i] > max)
        {
            max = src[i];
            max_id = i;
        }
    }
    return max_id;
}

/* 核信息之间的初始化 */
void Core_Init(void)
{
	int i = 0;
	
	core_share_mi.in = 0;
	core_share_mi.out = 0;
	core_share_mi.empty_count = N;
	core_share_mi.produce_count = 0;

	for (i = 0; i < N; i++)
	{
		memset(core_share_mi.rgb888_buff[i], 0, BUFF_WIDE);
	}
}

/**********************************************
*该函数实现如下3个功能 								  *
*0:取数据			   							  *
*1:把数据传入kpu							 	      *
*2:kpu进行计算		                              *
*3:通过uart输出		                              *
**********************************************/
void Core1_Function()
{
	//获取core id
	uint64_t core = current_coreid();
	printf("Core1_Function core = %d\r\n", core);

	//kpu的一些初始化
	
	//uart的初始化
	uart_init(UART_NUM);
	uart_configure(UART_NUM, 115200, 8, UART_STOP_1, UART_PARITY_NONE);
	
	while (1)
	{
		//减少产品的数量
		semaphore_wait(&core_share_mi.semaphore_lock, core_share_mi.produce_count);
		//取出产品,把数据传入kpu并进行计算最后uart输出
		
		
		//增加空产品数量
		semaphore_signal(&core_share_mi.semaphore_lock, core_share_mi.empty_count);
		
		//in的值要改变
		core_share_mi.out = (core_share_mi.out + 1) % N;
	}
}


/////////////////////////////////////
//#define PLL0_OUTPUT_FREQ 		800000000UL
//#define PLL1_OUTPUT_FREQ 		300000000UL
//#define PLL2_OUTPUT_FREQ 		45158400UL
//#define PLL0_MAX_OUTPUT_FREQ 	1000000000UL


/*定义从机引脚*/
#define SPI_SLAVE_INT_PIN       18
#define SPI_SLAVE_INT_IO        4
#define SPI_SLAVE_READY_PIN     26
#define SPI_SLAVE_READY_IO      5

#define SPI_SLAVE_CS_PIN        22
#define SPI_SLAVE_CLK_PIN       28
#define SPI_SLAVE_MOSI_PIN      30
//#define SPI_SLAVE_MISO_PIN    20

//uart
#define UART_RX_PIN   8
#define UART_TX_PIN   6
#define UART_UNKNOW   33

static void io_mux_init(void)
{
	//uart
//	fpioa_set_function(UART_RX_PIN, FUNC_UART1_RX + UART_NUM * 2);
//    fpioa_set_function(UART_TX_PIN, FUNC_UART1_TX + UART_NUM * 2);
//    fpioa_set_function(UART_UNKNOW, FUNC_GPIOHS3);
	
	//spi
	fpioa_set_function(37, FUNC_GPIOHS0 + RST_GPIONUM); 
    fpioa_set_function(38, FUNC_GPIOHS0 + DCX_GPIONUM); 
    fpioa_set_function(36, FUNC_SPI0_SS3);
    fpioa_set_function(39, FUNC_SPI0_SCLK);
	sysctl_set_spi0_dvp_data(1);
}

void rgb888_to_lcd(uint8_t *src, uint16_t *dest, size_t width, size_t height)
{
    size_t i, chn_size = width * height;
    for (size_t i = 0; i < width * height; i++)
    {
        uint8_t r = src[i];
        uint8_t g = src[chn_size + i];
        uint8_t b = src[chn_size * 2 + i];

        uint16_t rgb = ((r & 0b11111000) << 8) | ((g & 0b11111100) << 3) | (b >> 3);
        size_t d_i = i % 2 ? (i - 1) : (i + 1);
        dest[d_i] = rgb;
    }
}

/*set power mode*/
static void io_set_power(void)
{
    sysctl_set_power_mode(SYSCTL_POWER_BANK0, POWER_BANK0_SELECT);
    sysctl_set_power_mode(SYSCTL_POWER_BANK1, POWER_BANK1_SELECT);
    sysctl_set_power_mode(SYSCTL_POWER_BANK2, POWER_BANK2_SELECT);
    sysctl_set_power_mode(SYSCTL_POWER_BANK3, POWER_BANK3_SELECT);
    sysctl_set_power_mode(SYSCTL_POWER_BANK4, POWER_BANK4_SELECT);
    sysctl_set_power_mode(SYSCTL_POWER_BANK5, POWER_BANK5_SELECT);
    sysctl_set_power_mode(SYSCTL_POWER_BANK6, POWER_BANK6_SELECT);
    sysctl_set_power_mode(SYSCTL_POWER_BANK7, POWER_BANK7_SELECT);
}

static uint8_t slave_cfg[32];
static uint8_t test_data_tmp[3 * 320 * 240];
static uint8_t RGB_Data[3 * 320 * 240];
static long  shift = 0;
static int count1 = 0;
static spi_slave_command_t *p = NULL;
//static unsigned char buff[43756] = {0};
//char buf[10] = {0};
/*spi接收数据的回调函数*/
int spi_slave_receive_hook(void *data)
{
	int i = 0;
	int left_len = 0;
	int width, height, comps, err;
	jpeg_image_t *img_data;
   	pjpeg_scan_type_t scan_type;
	
	if (data < 0 || NULL == data)
	{
		printf("Not Receive Video Data!!!\r\n");
		return DW_FALSE;
	}
	p = (spi_slave_command_t *)data;

	if (p->cmd == 2)
	{
		count1++;
	//	printf("count1 = %d\r\n", count1);
	//	printf("shift = %ld", shift);
		//判断是否要删除添加为16倍数的字节数,这个不做清除应该也是可以的
		if (16 != (left_len = ((uint8_t*)(p->addr))[0]))
		{
			//printf("left_len = %d\r\n", left_len);
			memset(RGB_Data + shift - left_len, 0, left_len);
		}

		//减少空产品的数量
		semaphore_wait(&core_share_mi.semaphore_lock, core_share_mi.empty_count);

		//开始转化为rgb888格式,并放入core_share_mi.test_data_tmp
		img_data = pjpeg_load_from_file(jpeg_picture_data, BUFF_WIDE, \
								&width, &height, &comps, &scan_type, 0, 0, NULL, &err);
		if (NULL == img_data)
		{
			printf("Convert Error!!!\r\n");
			return 0;
		}

		//把转化的放入缓存区
		memcpy(core_share_mi.rgb888_buff[core_share_mi.in], img_data, BUFF_WIDE);	

		//增加产品数量
		semaphore_signal(&core_share_mi.semaphore_lock, core_share_mi.produce_count);

		//in的值要改变
		core_share_mi.in = (core_share_mi.in + 1) % N;

		
		//数据处理完就清除一帧数据
		//memset(RGB_Data, 0, 3*240*320);
		shift = 0;
//		free(Valid_Data);
		return DW_SUCCESS;
	}
	
	if (p->cmd == 4)
	{
		p->len = (p->len) << 4;
		for (i = 0; i < p->len; i++)
		{
			RGB_Data[i + shift] = ((uint8_t*)(p->addr))[i];
		}
		
		//printf("p->len = %d\r\n", p->len);
#if 1		
		//做交换
		for (i = 0; i < ((p->len) / 4); i++)
		{
				unsigned char temp;
				
				temp = RGB_Data[((4 * i) + shift)];
				RGB_Data[((4 * i) + shift)] = RGB_Data[((4 * i)) + 3 + shift];
				RGB_Data[((4 * i) + shift) + 3] = temp;
	
				temp = RGB_Data[(4 * i) + 1 + shift];
				RGB_Data[(4 * i) + 1 + shift] = RGB_Data[((4 * i)) + 2 + shift];
				RGB_Data[(4 * i) + 2 + shift] = temp;
		}
#endif 	
		shift += p->len;
		//printf("shift = %d\r\n", shift);
	}
	
	return DW_SUCCESS;
}


/*管脚的初始化，设置复用的模式,从模式只有一个*/
DW_S32 DW_SPI_SLAVE_Init(uint8_t *data, uint32_t len)
{
	DW_S32 s32Ret;
	/*SPI CS*/
	s32Ret = fpioa_set_function(SPI_SLAVE_CS_PIN, FUNC_SPI_SLAVE_SS);
	if (DW_SUCCESS != s32Ret)
	{
		//printf("SPI_SLAVE_CS_PIN set error!!!\n");
		return DW_FALSE;
	}

	/*SPI clock*/
	s32Ret = fpioa_set_function(SPI_SLAVE_CLK_PIN, FUNC_SPI_SLAVE_SCLK);
	if (DW_SUCCESS != s32Ret)
	{
		//printf("SPI_SLAVE_CLK_PIN set error!!!\n");
		return DW_FALSE;
	}
#if 1
	/*SPI MOSI*/
	s32Ret = fpioa_set_function(SPI_SLAVE_MOSI_PIN, FUNC_SPI_SLAVE_D0);
	if (DW_SUCCESS != s32Ret)
	{
		//printf("SPI_SLAVE_MOSI_PIN set error!!!\n");
		return DW_FALSE;
	}
#endif

#if 0
	/*SPI MISO*/
	s32Ret = fpioa_set_function(SPI_SLAVE_MISO_PIN, FUNC_SPI_SLAVE_D0);
	if (DW_SUCCESS != s32Ret)
	{
		printf("SPI_SLAVE_MISO_PIN set error!!!\n"); 
		return DW_FALSE;
	}			
#endif	
	/*interrupt pin set 18 FUNC_GPIOHS4 与CS相连接表示主机要发送数据了*/
	s32Ret = fpioa_set_function(SPI_SLAVE_INT_PIN, FUNC_GPIOHS0 + SPI_SLAVE_INT_IO); //28
	if (DW_SUCCESS != s32Ret)
	{
		//printf("SPI_SLAVE_INT_PIN set error!!!\n");
		return DW_FALSE;
	}
	
    s32Ret = fpioa_set_function(SPI_SLAVE_READY_PIN, FUNC_GPIOHS0 + SPI_SLAVE_READY_IO); //29
	if (DW_SUCCESS != s32Ret)
	{
		//printf("SPI_SLAVE_READY_PIN set error!!!\n");
		return DW_FALSE;
	}
	
	/*set slave mode */
	spi_slave_config(SPI_SLAVE_INT_IO, SPI_SLAVE_READY_IO, DMAC_CHANNEL5, 8, data, len, spi_slave_receive_hook);

	return DW_SUCCESS;
	
}

int main()
{	
	int i = 0;
	unsigned char uart_send_test[1] = {0x41};
	unsigned char buf[10];
	/* Set CPU and dvp clk */
    //sysctl_pll_set_freq(SYSCTL_PLL0, PLL0_MAX_OUTPUT_FREQ); //PLL0_OUTPUT_FREQ
    sysctl_pll_set_freq(SYSCTL_PLL0, PLL0_OUTPUT_FREQ);
    sysctl_pll_set_freq(SYSCTL_PLL1, PLL1_OUTPUT_FREQ);
    sysctl_pll_set_freq(SYSCTL_PLL2, PLL2_OUTPUT_FREQ);
	sysctl_clock_enable(SYSCTL_CLOCK_AI);
	//uart
	//uart_init(UART_NUM);
	//uart_configure(UART_NUM, 115200, 8, UART_STOP_1, UART_PARITY_NONE);

	dmac_init();
	uarths_init();
	io_set_power();
	plic_init();
	//sysctl_enable_irq();
#if 1	
	/* LCD init */
    //printf("LCD init\n");
    io_mux_init();
    lcd_init();
	lcd_set_direction(DIR_YX_RLDU);
    lcd_clear(BLACK);
    lcd_draw_string(104, 110, "Naxclow LAB . 2019", RED);

	//uint64_t tm = sysctl_get_time_us();
	//jpeg_image_t *jpeg = pico_jpeg_decode(buff, sizeof(buff));
#endif	
	/**init spi**/
	*(uint32_t *)(&slave_cfg[8]) = (uint32_t)test_data_tmp;
	DW_SPI_SLAVE_Init(slave_cfg, 32);

	/* enable global interrupt */
    sysctl_enable_irq();
/*
	for (i = 0; i < sizeof(jpeg_head); i++)
	{
		buff[i] = jpeg_head[i];
	}
*/
	//memcpy(buff, jpeg_head, sizeof(jpeg_head));
	//rgb888_to_lcd(gImage_image, lcd_gram, 320, 240);
    //lcd_draw_picture(0, 0, 320, 240, lcd_gram);
	//uart_send_data(UART_NUM, uart_send_test, 1); 
	while(1)
	{
		;
	}

}


